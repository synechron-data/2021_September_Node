const express = require('express');
const { body } = require('express-validator');

const router = express.Router();

const accCtrl = require('../controllers/account-controller');
const usersCtrl = require('../controllers/users-controller');

router.use(accCtrl.isAuthenticated);

router.get('/', usersCtrl.index);

module.exports = router;
