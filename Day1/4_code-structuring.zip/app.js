// var logger1 = require('./logger.js');
// var logger2 = require('./logger.js');

// console.log(logger1 === logger2);

// -------------------------------------------------
// var logger = require('./logger/index');
// var logger = require('./logger/myLogger');
// var logger = require('./logger');

// -------------------------------------------------
// const loggerService = require('./loggerService');
// loggerService.log("Hi from App Module");

// const loggerSingle = require('./loggerSingle');

// let l1 = loggerSingle.getLogger();
// l1.log("Hello from App Module");

// let l2 = loggerSingle.getLogger();
// l2.log("Hello from App Module");

// console.log(l1 === l2);

// ----------------------------------------------- Assignment

const loggerFactory = require('./loggerFactory');