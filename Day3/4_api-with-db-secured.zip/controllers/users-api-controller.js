const da = require('../data-access');
const User = require('../models/user');

exports.getAllUsers = function (req, res, next) {
    da.getAllUsers().then(result => {
        res.status(200).json({ data: result, message: "Success, Getting Users" });
    }, eMsg => {
        res.status(404).json({ data: [], message: "Error, Getting Users" });
    });
}

exports.getUser = function (req, res, next) {
    da.getUser(req.params.userid).then(result => {
        res.status(200).json({ data: result, message: "Success, Getting User" });
    }, eMsg => {
        res.status(404).json({ data: null, message: "Error, Getting Users" });
    });
}

exports.createUser = function (req, res, next) {
    var user = new User(req.body.username, req.body.email);

    da.insertUser(user).then(result => {
        res.status(201).json({ data: result, message: "Success, Inserting User" });
    }, eMsg => {
        res.status(400).json({ data: null, message: "Error, Inserting Users" });
    });
}

exports.updateUser = function (req, res, next) {
    var user = new User(req.body.username, req.body.email);

    da.updateUser(req.params.userid, user).then(result => {
        res.status(200).json({ data: result, message: "Success, Updating User" });
    }, eMsg => {
        res.status(404).json({ data: null, message: "Error, Updating Users" });
    });
}

exports.deleteUser = function (req, res, next) {
    da.deleteUser(req.params.userid).then(result => {
        res.status(204).json({ data: null, message: "Success, Deleting User" });
    }, eMsg => {
        res.status(404).json({ data: null, message: "Error, Deleting Users" });
    });
}