// console.log("This is the lib module");
// console.log(module);

// var fname = "Manish";
// module.exports = fname;

// var lname = "Sharma";
// module.exports = lname;

// var fname = "Manish";
// var lname = "Sharma";
// module.exports = { firstname: fname, lastname: lname };

// // ---------------------------------------------- Named Exports
// var fname = "Manish";
// var lname = "Sharma";

// module.exports.firstname = fname;
// module.exports.lastname = lname;

// module.exports.log = function (message) {
//     return `From Lib - ${message.toUpperCase()}`;
// };

// ---------------------------------------------- Named Exports Shortcut
var fname = "Manish";
var lname = "Sharma";

exports.firstname = fname;
exports.lastname = lname;

exports.log = function (message) {
    return `From Lib - ${message.toUpperCase()}`;
};

// Create and export a class Employee from Lib

// exports.Employee = (function () {
//     function Employee(name) {
//         this._name = name;
//     }

//     Employee.prototype.getName = function () {
//         return this._name;
//     }

//     Employee.prototype.setName = function (value) {
//         this._name = value;
//     }

//     return Employee;
// })();

// exports.Employee = class {
//     constructor(name) {
//         this._name = name;
//     }

//     getName() {
//         return this._name;
//     }

//     setName(value) {
//         this._name = value;
//     }
// }

class Employee {
    constructor(name) {
        this._name = name;
    }

    getName() {
        return this._name;
    }

    setName(value) {
        this._name = value;
    }
}

exports.Employee = Employee;