const express = require('express');
const router = express.Router();
var cors = require('cors');

const usersApiCtrl = require('../controllers/users-api-controller');

router.use(cors());

router.get('/', usersApiCtrl.getAllUsers);

module.exports = router;
