// The fs module provides a lot of very useful functionality 
// to access and interact with the file system.

const fs = require('fs');
// console.log(fs);

// Async
// fs.readFile('./file1.txt', 'utf-8', (err, data) => {
//     if (err)
//         console.log(err);
//     else
//         console.log(data);
// });

// Sync
// try {
//     var data = fs.readFileSync('./file1.txt', 'utf-8');
//     console.log(data);
// } catch (err) {
//     console.log(err);
// }

// fs.writeFile('./file2.txt', "Hello from Node Application", 'utf-8', (err) => {
//     if (err)
//         console.log(err);
//     else
//         console.log("File Write Completed....");
// });

fs.appendFile('./file3.txt', "Hello from Node Application\n", 'utf-8', (err) => {
    if (err)
        console.log(err);
    else
        console.log("File Append Completed....");
});

console.log("Completed and waiting....");
