const express = require('express');
const router = express.Router();
var cors = require('cors');

const accountCtrl = require('../controllers/account-controller');
const usersApiCtrl = require('../controllers/users-api-controller');

router.use(cors());

router.use(accountCtrl.validateToken);

// GET - /api/users (Get All users)
router.get('/', usersApiCtrl.getAllUsers);

// GET - /api/users/:userid  (Get single user by id)
router.get('/:userid', usersApiCtrl.getUser);

// POST - /api/users (Create an user)
router.post('/', usersApiCtrl.createUser);

// PUT - /api/users/:usedid (Update an user)
router.put('/:userid', usersApiCtrl.updateUser);

// DELETE - /api/users/:usedid (Delete an user)
router.delete('/:userid', usersApiCtrl.deleteUser);

module.exports = router;
