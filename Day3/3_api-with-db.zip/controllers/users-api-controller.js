const da = require('../data-access');

exports.getAllUsers = function (req, res, next) {
    da.getAllUsers().then(result => {
        res.json({ data: result, message: "Success, Getting Users" });
    }, eMsg => {
        res.json({ data: [], message: "Error, Getting Users" });
    });
}