import { Employee } from './lib';
const http = require('http');
console.log(http);

// let e1: Employee = new Employee("Manish");
// console.log(e1.getName());
// e1.setName("Abhijeet");
// console.log(e1.getName());