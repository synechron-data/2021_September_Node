exports.isAuthenticated = function (req, res, next) {
    // Logic to check User Authenticatin Status

    // res.status(401).send("Unauthorized Access!");

    if (req.isAuthenticated()) {
        next();
    } else {
        res.redirect('/account');
    }
};

exports.login_get = function (req, res, next) {
    res.render('account/login', { title: 'Login', message: req.flash('loginMessage') });
};

exports.login_post = function (passport) {
    // Logic to Authenticate the user & Redirect

    return passport.authenticate('local-login', {
        successRedirect: '/users',
        failureRedirect: '/account',
        failureFlash: true
    });
};

// ---------------------------------------------------------- JWT Code
const jwt = require('jsonwebtoken');
const key = process.env.TOKEN_KEY;

exports.createToken = function (req, res, next) {
    var user = {
        username: req.body.username,
        password: req.body.password
    };

    if (user.username !== "manish") {
        res.status(403).json({
            success: false,
            message: "Authentication Failed, User not Found..."
        });
    } else if (user.password !== "manish") {
        res.status(403).json({
            success: false,
            message: "Authentication Failed, Wrong Password..."
        });
    } else {
        var token = jwt.sign(user.username, key);
        res.json({
            success: true,
            message: "Authentication Success...",
            token: token
        });
    }
};

exports.validateToken = function (req, res, next) {
    var token = req.headers['x-access-token'];

    if (token) {
        jwt.verify(token, key, function(err, decoded){
            if(err){
                res.status(403).json({
                    success: false,
                    message: "Invalid Token Found"
                });
            } else {
                req.decoded = decoded;
                next();
            }
        })
    } else {
        res.status(403).json({
            success: false,
            message: "No Token Found"
        });
    }
};